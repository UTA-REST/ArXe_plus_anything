# ArXe_plus_anything
Contains magboltz simulations of argon or xenon plus all gases in magboltz at various concentrations
## Importing to your python code 
```
$ sudo pip3 install git+https://github.com/UTA-REST/ArXe_plus_anything
```


